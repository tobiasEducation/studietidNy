// Eksempel på en liste med personer
let persons = [
    {
        "name": "Ola Nordmann",
        "age": 30,
        "email": "ola@example.com"
    },
    {
        "name": "Kari Nordmann",
        "age": 25,
        "email": "kari@example.com"
    }
];

document.getElementById('addPersonBtn').addEventListener('click', addPerson);
fetchRandomUsers()

// Funksjon for å vise listen med personer på nettsiden
function displayPersons() {
    const personList = document.getElementById('personList');
    personList.innerHTML = ''; // Tøm listen først
    
    persons.forEach(person => {
        const listItem = document.createElement('li');
        listItem.textContent = `${person.name}, ${person.age} år, Email: ${person.email}`;
        personList.appendChild(listItem);
    });
}

// Funksjon for å legge til en ny person til listen
function addPerson() {
    const newPerson = {
        "name": "Per Hansen",
        "age": 28,
        "email": "per@example.com"
    };
    
    persons.push(newPerson);
    displayPersons(); // Oppdater visningen
}



// Kall funksjonen for å vise listen med en gang siden lastes
displayPersons();




// Funksjon for å hente tilfeldige brukere fra Random User API

    async function fetchRandomUsers() {
        try {
            // Fetch API brukes for å hente data fra URLen
            let response = await fetch('https://randomuser.me/api/?results=5'); // Henter 5 tilfeldige brukere
            let data = await response.json(); // Konverterer responsen til JSON
            console.log(data); // Logger hentet data for testing
        } catch (error) {
            console.error('Error:', error); // Håndterer eventuelle feil
        }
    }
    
